<img alt="avatar" class="rounded-circle avatar-md me-2"
src="{{ asset('storage/' . $image) }}">
