<div class="d-flex text-center  ">
    <hr style="width:40% ; height: 3px;">
    <span class="text-success mx-3">{{ $content }}</span>
    <hr  style="width:40% ;  height: 3px;">
</div>
