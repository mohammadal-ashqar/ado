<li class="slide">
    <a class="side-menu__item" href="{{ $route }}">
        <i class="{{ $icon }}   side-menu__icon"></i>
        <span class="side-menu__label">{{ $lable }}</span></a>
</li>
