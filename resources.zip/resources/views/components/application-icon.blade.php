<img src="{{ asset('assets/images/ado-dark-logo.png') }}" {{ $attributes }}>
  </img>
