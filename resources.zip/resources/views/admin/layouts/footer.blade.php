<div class="main-footer ht-45">
    <div class="container-fluid pd-t-0 ht-100p">
        <span> Copyright © {{date('Y')}} <a href="javascript:void(0);" class="text-primary">Alama</a>. Designed with <span
                class="fa fa-heart text-danger"></span> by <a href="https://jadwa.ps"> Jadwa </a> All rights
            reserved.</span>
    </div>
</div>
